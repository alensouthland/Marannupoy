require 'test_helper'

class FoundTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
